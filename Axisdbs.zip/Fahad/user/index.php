<?php
  include_once("custom_functions.php");
  include_once("mysqlconnect.php");
  session_start(); 
  if(!userloggedin())
    header('Location: ../login.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Axis DBS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <link href="css/theme.css" rel="stylesheet">
 
</head>
<body>
<nav class="navbar navbar-inverse visible-xs">
 <?php include_once "left-menu.php";?>
    
    <div class="col-sm-10">
    

    <div class="well">
        <h4>Admin Dashboard</h4>
        <p>Description here...</p>

      </div>
      <div class="row">
        <div class="col-sm-6">
          <div class="well">
            <h4>Projects</h4>
            <hr>
            <p>Total projects: 0</p>
            <p>Completed projects: 0</p>
            <p>Ongoing projects: 0</p>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="well">
            <h4>Users</h4>
            <hr>
            <p>Total users: 0</p>
            <p>Free users: 0</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
