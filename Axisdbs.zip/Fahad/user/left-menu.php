﻿<?php 
  require_once('custom_functions.php');
?>
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Axis DBS</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">

        <li class="active"><a href="index.php">Dashboard</a></li>
          <li><a href="projects.php">Projects</a></li>
          <li><a href="users.php">Users</a></li>
          <li><a href="logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid">
  <div class="row content">
    <div class="col-sm-2 sidenav hidden-xs">
      <br>
      <center><img src="images/logo.PNG" width="200"></center>
      <br><br>
      <ul class="nav nav-pills nav-stacked">
          <li class="secondary"><a href="index.php">Dashboard</a></li>
          <br>
          <li><a href="#">Projects</a></li>
          <ul class="nav nav-pills">
            <li><a href="all-projects.php">All Projects</a></li>
            <li><a href="add-project.php">Add Project</a></li>
          </ul> 
          <br>
          <li><a href="#">Users</a></li>
          <ul class="nav nav-pills">
            <li><a href="all-users.php">All Users</a></li>
            <li><a href="add-user.php">Add User</a></li>
          </ul>
          <br>
          <li><a href="logout.php">Logout</a></li>
      </ul><br>
    </div>
    <br>
