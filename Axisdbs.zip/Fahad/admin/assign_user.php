<?php
  include_once("custom_functions.php");
  include_once("mysqlconnect.php");

  session_start();
  if(!adminloggedin())
    header('Location: ../login.php');

  if(!isset($_GET['id']))
    header('Location: all-projects.php');

  $project = simplequeryrun("SELECT * from projects where id = '".$_GET['id']."'",$conn);

  if(isset($_POST['submit'])){

      $user_id = $_POST['user_id'];
      $description = forminputsecure($_POST['description']);
      $project_id = $_POST['project_id'];
      $status = 'active';
      $start_date = date('Y-m-d');
      $start_admin_id = getadminid();

      $row = simplequeryrun("SELECT id from project_users where project_id = '".$project_id."' AND user_id = '".$user_id."'",$conn);
      if($row)
          header('Location: assign_user.php?id='.$project_id.'&&msg='.urlencode(base64_encode("exists")));
      else{
          $query = "INSERT INTO project_users(user_id,project_id,description,status,start_date,start_admin_id) VALUES('".$user_id."','".$project_id."','".$description."','".$status."','".$start_date."','".$start_admin_id."')";
          $result = mysqli_query($conn, $query);

          if($result)
              header('Location: project.php?id='.$project_id.'&&msg='.urlencode(base64_encode("assign")));
          else
              header('Location: assign_user.php?id='.$project_id.'&&msg='.urlencode(base64_encode("error")));
      }
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Axis DBS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="css/theme.css" rel="stylesheet">
<style>
.container {
    padding: 16px;
    background-color: white;
}
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}
.registerbtn {
    background-color: #337AB7;
    color: white;
    padding: 16px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}
.registerbtn:hover {
    opacity: 1;
}
/* Add a blue text color to links */
a {
    color: dodgerblue;
}
</style>

</head>
<body>
<nav class="navbar navbar-inverse visible-xs">
 <?php include_once "left-menu.php";?>
    
<div class="col-sm-10">
  <div class="well">
    <h4><a href="index.php">Dashboard</a> > <a href="all-projects.php">All Projects</a> > <a href="project.php?id=<?php echo $project['id']; ?>"><?php echo $project['name']; ?></a></h4>
    <p></p>
  </div>
 
  <div class="row"> 
    <div class="col-sm-6">
    <?php
    if(isset($_GET['msg'])){
      if(!strcmp($_GET['msg'],urlencodefuncforerrors("exists"))){
    ?>
    <div class="alert alert-danger">User already assigned.</div>
    <?php } if(!strcmp($_GET['msg'],urlencodefuncforerrors("error"))){
    ?>
    <div class="alert alert-danger">Some error occurs, try again later.</div>
    <?php } } ?> 
      <div>
      <form action="assign_user.php" method="POST" enctype="multipart/form-data">
      <h1>Add User to <?php echo $project['name']; ?></h1>
      <hr>

      <input type="hidden" name="project_id" value="<?php echo $_GET['id']; ?>">

      <label for="psw"><b>Users</b></label>
      <select class="form-control" name="user_id">
        <?php
        $types = queryrunloop("SELECT * from users ORDER BY firstname",$conn);
        if (mysqli_num_rows($types) > 0){
            while($row = mysqli_fetch_array($types, MYSQL_ASSOC)){
        ?>
        <option value="<?php echo $row['id']; ?>"><?php echo $row['firstname'].' '.$row['lastname']; ?></option>
        <?php }} ?>
      </select>
      <br>
      
      <label for="psw-repeat"><b>Description</b></label>
      <textarea class="form-control" input type="text" name="description" required placeholder="Enter Description" rows="5"></textarea>
      <br>

      <hr>
      <button type="submit" name="submit" class="registerbtn">Add</button>
      </form>
      </div>
    </div>
    <div class="col-sm-6">
      <div class="well">Instructions</div>
    </div>
  </div>
</div>

</body>
</html>
