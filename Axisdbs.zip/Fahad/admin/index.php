<?php
  include_once("custom_functions.php");
  include_once("mysqlconnect.php");
  session_start(); 
  if(!adminloggedin())
    header('Location: ../login.php');

  $row = simplequeryrun("SELECT * from admin where id = '".getadminid()."' ",$conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Axis DBS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

 <link href="css/theme.css" rel="stylesheet">
 
</head>
<body>
<nav class="navbar navbar-inverse visible-xs">
 <?php include_once "left-menu.php"; ?>
    
    <div class="col-sm-10">
    

    <div class="well">
        <h4>Welcome back, <?php echo $row['firstname'].' '.$row['lastname']; ?></h4>
        <p>Description here...</p>

      </div>
      <div class="row">
        <div class="col-sm-6">
          <div class="well">
            <h4>Projects</h4>
            <hr>
            <?php 
              $total_projects = simplequeryrun("SELECT COUNT(id) as total from projects WHERE start_admin_id = '".getadminid()."'",$conn);
              $completed_projects = simplequeryrun("SELECT COUNT(id) as total from projects WHERE status LIKE 'completed' AND start_admin_id = '".getadminid()."'",$conn);
              $ongoing_projects = simplequeryrun("SELECT COUNT(id) as total from projects WHERE status LIKE 'active' AND start_admin_id = '".getadminid()."'",$conn);
            ?>
            <p>Total projects: <?php echo $total_projects['total']; ?></p>
            <p>Completed projects: <?php echo $completed_projects['total']; ?></p>
            <p>Ongoing projects: <?php echo $ongoing_projects['total']; ?></p>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="well">
            <h4>Users</h4>
            <hr>
            <?php 
              $total_users = simplequeryrun("SELECT COUNT(id) as total from users",$conn);
            ?>
            <p>Total users: <?php echo $total_users['total']; ?></p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>
