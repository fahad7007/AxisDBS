<?php
  include_once("custom_functions.php");
  include_once("mysqlconnect.php");
  session_start(); 
  if(!adminloggedin())
    header('Location: ../login.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Axis DBS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="css/theme.css" rel="stylesheet">
  <style>
 

  /* Style the search field */
  form.example input[type=text] {
    padding: 10px;
    font-size: 17px;
    border: 1px solid grey;
    float: left;
    width: 80%;
    background: #f1f1f1;
  }

  /* Style the submit button */
  form.example button {
    float: left;
    width: 20%;
    padding: 10px;
    background: #337AB7;
    color: white;
    font-size: 17px;
    border: 1px solid grey;
    border-left: none; /* Prevent double borders */
    cursor: pointer;
  }

  form.example button:hover {
    background: #0b7dda;
  }

  /* Clear floats */
  form.example::after {
    content: "";
    clear: both;
    display: table;
  }
  table {
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
      border: 1px solid #ddd;
  }

  th, td {
      text-align: left;
      padding: 8px;
  }

  tr:nth-child(even){background-color: #f2f2f2}
  </style>
</head>
<body>
<nav class="navbar navbar-inverse visible-xs">
 <?php include_once "left-menu.php";?>
    
<div class="col-sm-10">
  <div class="well">
    <h4><a href="index.php">Dashboard</a> > <a href="all-projects.php">All Projects</a></h4>
    <p></p>
  </div>   

  <?php
  if(isset($_GET['msg'])){
  if(!strcmp($_GET['msg'],urlencodefuncforerrors("added"))){
  ?>
  <div class="alert alert-success">Project added successfully.</div>
  <?php }} ?>
<div class="col-sm-8">
  <div>
  <div style="overflow-x:auto;">
    <h1>Active</h1>
  <table>
    <tr>
      <th>Project Name</th>
      <th>Type</th>
      <th>No.of users</th>
      <th>No.of requirements</th>
      <th>Start Date</th>
      <th>Edit</th>
    </tr>

    <?php
      $no_record = true;
      $projects = queryrunloop("SELECT * from projects WHERE status LIKE 'active' AND start_admin_id = '".getadminid()."' ORDER BY id DESC",$conn);
      if (mysqli_num_rows($projects) > 0){
          while($row = mysqli_fetch_array($projects, MYSQL_ASSOC)){
            $no_record = false;
            $type = simplequeryrun("SELECT name from project_types where id='".$row['type_id']."' ",$conn);
            $total_revisions = simplequeryrun("SELECT COUNT(id) as total from project_requirements WHERE project_id = '".$row['id']."'",$conn);
            $total_users = simplequeryrun("SELECT COUNT(id) as total from project_users WHERE project_id = '".$row['id']."'",$conn);
    ?>

    <tr>
      <td><a href="project.php?id=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></td>
      <td><?php echo $type['name']; ?></td>
      <td><?php echo $total_users['total']; ?></td>
      <td><?php echo $total_revisions['total']; ?></td>
      <td><?php echo $row['start_date']; ?></td>
      <td><a href="#">Edit</a></td>
    </tr>

    <?php }} ?>
    
  </table>

  <?php if($no_record){ echo '</br><center><div class="alert alert-info">No project added yet!</div></center>'; } ?>

  </div>
  </div>

</div>

<div class="col-sm-4">
  <div>
  <div style="overflow-x:auto;">
    <h1>Completed</h1>
  <table>
    <tr>
      <th>Project Name</th>
      <th>Type</th>
      <th>Start Date</th>
      <th>End Date</th>
      <th>Edit</th>
    </tr>
    
    <?php
      $no_record = true;
      $projects = queryrunloop("SELECT * from projects WHERE status LIKE 'completed' ORDER BY id DESC",$conn);
      if (mysqli_num_rows($projects) > 0){
          while($row = mysqli_fetch_array($projects, MYSQL_ASSOC)){
            $no_record = false;
            $type = simplequeryrun("SELECT name from project_types where id='".$row['type_id']."' ",$conn);
    ?>

    <tr>
      <td><a href="project.php?id=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></td>
      <td><?php echo $type['name']; ?></td>
      <td><?php echo $row['start_date']; ?></td>
      <td><?php echo $row['end_date']; ?></td>
      <td><a href="#">Edit</a></td>
    </tr>

    <?php }} ?>
  </table>

  <?php if($no_record){ echo '</br><center><div class="alert alert-info">No project completed yet!</div></center>'; } ?>

  </div>
  </div>

</div>


</div>
</body>
</html>
