<?php
  include_once("custom_functions.php");
  include_once("mysqlconnect.php");
  session_start(); 
  if(!adminloggedin())
    header('Location: ../login.php');

  if(!isset($_GET['id']))
    header('Location: all-projects.php');

  $project_requirements = simplequeryrun("SELECT * from project_requirements where id = '".$_GET['id']."'",$conn);
  $project = simplequeryrun("SELECT * from projects where id = '".$project_requirements['project_id']."'",$conn);
  $type = simplequeryrun("SELECT name from project_types where id='".$project['type_id']."' ",$conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Axis DBS</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="css/theme.css" rel="stylesheet">
    <style>
 

  /* Style the search field */
  form.example input[type=text] {
    padding: 10px;
    font-size: 17px;
    border: 1px solid grey;
    float: left;
    width: 80%;
    background: #f1f1f1;
  }

  /* Style the submit button */
  form.example button {
    float: left;
    width: 20%;
    padding: 10px;
    background: #337AB7;
    color: white;
    font-size: 17px;
    border: 1px solid grey;
    border-left: none; /* Prevent double borders */
    cursor: pointer;
  }

  form.example button:hover {
    background: #0b7dda;
  }

  /* Clear floats */
  form.example::after {
    content: "";
    clear: both;
    display: table;
  }
  table {
      border-collapse: collapse;
      border-spacing: 0;
      width: 100%;
      border: 1px solid #ddd;
  }

  th, td {
      text-align: left;
      padding: 8px;
  }

  tr:nth-child(even){background-color: #f2f2f2}

  </style>
</head>
<body>
<nav class="navbar navbar-inverse visible-xs">
 <?php include_once "left-menu.php";?>
    
<div class="col-sm-10">
  <div class="well">
    <h4><a href="index.php">Dashboard</a> > <a href="all-projects.php">All Projects</a> > <a href="project.php?id=<?php echo $project['id']; ?>"><?php echo $project['name']; ?></a> > <?php echo $project_requirements['name']; ?></h4>
    <p></p>
  </div>   


<div class="col-sm-4">
  <h1><?php echo $project['name']; ?></h1>
  <p><?php echo $type['name']; ?></p>
  <p><?php echo $project['description']; ?></p>

  <hr>

  <h1><?php echo $project_requirements['name']; ?></h1>
  <p><?php echo $project_requirements['description']; ?></p>

</div>

<div class="col-sm-8">
  <h1>Comments</h1>

  <table>
    <tr>
      <th>User</th>
      <th>Comment</th>
    </tr>

    <tr>
      <td>XYZ</td>
      <td>askjhdjashgfjkdasgdfiujas</td>
    </tr>
    <tr>
      <td>XYZ</td>
      <td>askjhdjashgfjkdasgdfiujas</td>
    </tr>
    <tr>
      <td>XYZ</td>
      <td>askjhdjashgfjkdasgdfiujas</td>
    </tr>
    <tr>
      <td>XYZ</td>
      <td>askjhdjashgfjkdasgdfiujas</td>
    </tr>
    <tr>
      <td>XYZ</td>
      <td>askjhdjashgfjkdasgdfiujas</td>
    </tr>
    <tr>
      <td>XYZ</td>
      <td>askjhdjashgfjkdasgdfiujas</td>
    </tr>
    <tr>
      <td>XYZ</td>
      <td>askjhdjashgfjkdasgdfiujas</td>
    </tr>
    
    
  </table>

</div>


</div>
</body>
</html>
